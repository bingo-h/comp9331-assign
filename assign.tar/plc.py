"""
PLC Module
"""

import random
import threading


class PlcModule:
    """Simulating packet loss and corruption on unreliable channels

    Attributes:
        flp (float): Forward loss rate
        rlp (float): Reverse loss rate
        fcp (float): Forward corruption rate
        rcp (float): Reverse corruption rate
        fd_dropped (int): Forward loss counter
        bk_dropped (int): Backward loss counter
        fd_corrupted (int): Forward corruption counter
        bk_corrupted (int): Backward corruption counter
    """

    def __init__(self, flp, rlp, fcp, rcp) -> None:
        self.flp = flp
        self.rlp = rlp
        self.fcp = fcp
        self.rcp = rcp

        # Statistics Information Thread Lock
        self.stats_lock = threading.Lock()

        # Statistics
        self.fwd_dropped = 0
        self.rev_dropped = 0
        self.fwd_corrupted = 0
        self.rev_corrupted = 0

    def process_fd(self, data):
        """Processing forward packets

        Sender --> PLC --> Receiver

        Returns:
            bytes: Segment data
            str: status, include: ok, drp (dropped), cor (corrupted)
        """

        if random.random() < self.flp:
            with self.stats_lock:
                self.fwd_dropped += 1
            return None, "drp"

        if random.random() < self.fcp:
            with self.stats_lock:
                self.fwd_corrupted += 1
            corrupted_data = self._corrupt_segment(data)
            return corrupted_data, "cor"

        return data, "ok"

    def process_bk(self, data):
        """Processing backward packets

        Sender <-- PLC <-- Receiver

        Returns:
            bytes: ACK data
            str: status, include: ok, drp, cor
        """

        if random.random() < self.rlp:
            with self.stats_lock:
                self.rev_dropped += 1
            return None, "drp"

        if random.random() < self.rcp:
            with self.stats_lock:
                self.rev_corrupted += 1
            corrupted_data = self._corrupt_segment(data)
            return corrupted_data, "cor"

        return data, "ok"

    @staticmethod
    def _corrupt_segment(data):
        """Damaged segment data

        Skip the first 4 bytes, randomly select one byte, and randomly flip one of its bits
        """

        if len(data) <= 4:
            return data

        data = bytearray(data)

        byte_pos = random.randint(4, len(data) - 1)
        bit_pos = random.randint(0, 7)
        data[byte_pos] ^= 1 << bit_pos

        return bytes(data)
